﻿namespace Decidir.Constants
{
    public sealed class Ambiente
    {
        public const int AMBIENTE_SANDBOX = 0;
        public const int AMBIENTE_PRODUCCION = 1;
        public const int AMBIENTE_QA = 2;
        public const int AMBIENTE_DESA = 3;
        public const int AMBIENTE_HOMO = 4;
    }
}
