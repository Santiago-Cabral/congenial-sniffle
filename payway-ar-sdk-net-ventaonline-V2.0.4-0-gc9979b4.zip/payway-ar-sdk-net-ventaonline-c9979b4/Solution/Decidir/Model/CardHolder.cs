﻿namespace Decidir.Model
{
    public class CardHolder
    {
        public string name { get; set; }
        public CardHolderIdentification identification { get; set; }
    }
}