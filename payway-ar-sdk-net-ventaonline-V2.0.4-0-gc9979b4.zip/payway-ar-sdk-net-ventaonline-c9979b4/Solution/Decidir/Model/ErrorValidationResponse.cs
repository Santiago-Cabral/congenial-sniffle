﻿namespace Decidir.Model
{
    public class ErrorValidationResponse
    {
        public string code { get; set; }
        public string param { get; set; }
    }
}
