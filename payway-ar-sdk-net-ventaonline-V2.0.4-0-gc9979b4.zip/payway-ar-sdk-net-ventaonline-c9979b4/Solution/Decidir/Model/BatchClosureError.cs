﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
    public class BatchClosureError
    {
        public string error_type { get; set; }
        public string error { get; set; }
    }
}