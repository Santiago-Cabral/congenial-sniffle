﻿namespace Decidir.Model
{
    public class TokenFraudDetection
    {
        public string device_unique_identifier { get; set; }
    }
}
