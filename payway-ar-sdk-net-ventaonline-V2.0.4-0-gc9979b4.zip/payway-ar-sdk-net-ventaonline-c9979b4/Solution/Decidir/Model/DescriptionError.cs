﻿namespace Decidir.Model
{
    public class DescriptionError
    {
        public string Description { get; set; }
    }
}