﻿

namespace Decidir.Model
{
    public class SiteInfo
    {
        public string transaction_id { get; set; }
        public TemplateValidate template { get; set; }
    }
}
