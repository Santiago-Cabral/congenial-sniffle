﻿namespace Decidir.Model
{
    public class StatusErrorReason
    {
        public int? id { get; set; }
        public string description { get; set; }
        public string additional_description { get; set; }
    }
}
