﻿namespace Decidir.Model
{
    public class CustomerData
    {
        public string id { get; set; }
        public string email { get; set; }
        public string ip_address { get; set; }
    }
}
