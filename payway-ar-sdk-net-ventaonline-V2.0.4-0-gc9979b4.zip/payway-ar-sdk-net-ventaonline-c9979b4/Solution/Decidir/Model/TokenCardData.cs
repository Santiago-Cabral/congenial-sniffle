﻿namespace Decidir.Model
{
    public class TokenCardData
    {
        public string token { get; set; }
        public string eci { get; set; }
        public string cryptogram { get; set; }

    }
}
