﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
    public class CardErrorReason
    {
        public int id { get; set; }
        public String description { get; set; }
        public String additional_description { get; set; }
    }
}
