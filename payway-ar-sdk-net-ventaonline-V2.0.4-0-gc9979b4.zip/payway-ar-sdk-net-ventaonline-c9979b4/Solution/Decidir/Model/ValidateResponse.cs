﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
    public class ValidateResponse
    {
        public int statusCode { get; set; }
        public string hash { get; set; }
    }
}
