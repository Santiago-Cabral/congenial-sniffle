﻿namespace Decidir.Model
{
    public class CardDataPayment
    {
        public string card_number { get; set; }
        public CardHolder card_holder { get; set; }
    }
}
