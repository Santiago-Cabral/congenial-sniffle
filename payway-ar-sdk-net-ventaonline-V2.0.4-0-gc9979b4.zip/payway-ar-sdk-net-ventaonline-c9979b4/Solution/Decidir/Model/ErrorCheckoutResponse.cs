﻿
namespace Decidir.Model
{
    public class ErrorCheckoutResponse : ErrorResponse
    {
        public string description { get; set; }

    }
}
