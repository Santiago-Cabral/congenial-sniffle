﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
    public class HttpThreeds
    {
        public String method { get; set; }
        public String url { get; set; }
        public String body { get; set; }
    }
}
