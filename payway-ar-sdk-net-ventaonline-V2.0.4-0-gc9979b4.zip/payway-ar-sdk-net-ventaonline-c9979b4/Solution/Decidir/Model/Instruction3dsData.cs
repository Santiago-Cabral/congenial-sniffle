﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
     public class Instruction3dsData
    {
        public string id { get; set; }
        public string instruction_value { get; set; }
    }
}
