﻿namespace Decidir.Model
{
    public class RefundAmount
    {
        public long amount { get; set; }
    }
}
