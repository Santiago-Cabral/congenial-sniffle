﻿namespace Decidir.Model
{
    public class ValidateCustomer
    {
        public string id { get; set; }
        public string email { get; set; }
    }
}