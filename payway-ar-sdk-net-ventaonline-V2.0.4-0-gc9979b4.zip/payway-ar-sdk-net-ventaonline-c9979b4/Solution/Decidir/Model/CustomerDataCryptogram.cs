﻿namespace Decidir.Model
{
    public class CustomerDataCryptogram
    {
        public string token_id { get; set; }
        public string identification_type { get; set; }
        public string identification_number { get; set; }

    }
}