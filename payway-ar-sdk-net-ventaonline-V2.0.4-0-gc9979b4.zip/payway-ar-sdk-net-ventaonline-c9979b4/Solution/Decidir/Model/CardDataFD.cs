﻿namespace Decidir.Model
{
    public class CardDataFD : CardData
    {
        public FraudDetectionBSA fraud_detection {  get; set; }

    }
}
