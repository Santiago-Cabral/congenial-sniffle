﻿namespace Decidir.Model.CyberSource
{
    public class PurchaseTotals
    {
        public string currency { get; set; }
        public long amount { get; set; }
    }
}
