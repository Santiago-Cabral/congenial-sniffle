﻿namespace Decidir.Model.CyberSource
{
    public class Csmdds
    {
        public int code { get; set; }
        public string description { get; set; }
    }
}
