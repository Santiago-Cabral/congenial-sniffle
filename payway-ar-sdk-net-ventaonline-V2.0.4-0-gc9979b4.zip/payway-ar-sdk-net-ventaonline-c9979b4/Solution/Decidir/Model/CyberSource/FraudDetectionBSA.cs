﻿namespace Decidir.Model
{
    public class FraudDetectionBSA
    {
        public string device_unique_identifier { get; set; }
    }
}