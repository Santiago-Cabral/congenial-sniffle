﻿using System.Collections.Generic;

namespace Decidir.Model.CyberSource
{
    public class FraudDetectionResponse
    {
        public FraudDetectionStatus status {  get; set; }
    }
}
