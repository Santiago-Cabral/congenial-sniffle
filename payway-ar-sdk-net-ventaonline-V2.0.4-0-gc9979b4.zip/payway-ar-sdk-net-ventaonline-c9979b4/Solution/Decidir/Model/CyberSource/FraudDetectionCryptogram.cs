﻿using System.Collections.Generic;

namespace Decidir.Model.CyberSource
{
    public class FraudDetectionCryptogram
    {
        public bool send_to_cs { get; set; }
        public string status { get; set; }
    }
}
