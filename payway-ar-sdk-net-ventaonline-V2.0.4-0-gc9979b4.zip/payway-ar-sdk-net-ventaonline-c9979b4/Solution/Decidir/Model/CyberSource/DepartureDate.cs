namespace Decidir.Model.CyberSource
{
    public class DepartureDate
    {
        public string departure_time { get; set; }
        public string departure_zone { get; set; }
    }
}
