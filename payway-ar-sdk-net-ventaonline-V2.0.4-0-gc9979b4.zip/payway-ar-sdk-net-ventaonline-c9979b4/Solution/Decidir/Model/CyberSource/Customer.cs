﻿namespace Decidir.Model.CyberSource
{
    public class Customer
    {
        public long days_in_site { get; set; }
        public bool is_guest { get; set; }
        public string password { get; set; }
        public long num_of_transactions { get; set; }
        public string cellphone_number { get; set; }
        public string date_of_birth { get; set; }
        public string street { get; set; }
    }
}
