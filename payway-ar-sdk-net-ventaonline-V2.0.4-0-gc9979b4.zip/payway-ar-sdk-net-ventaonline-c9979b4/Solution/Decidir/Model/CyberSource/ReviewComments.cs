using System.Collections.Generic;

namespace Decidir.Model.CyberSource
{
    public class ReviewComments
    {
        public string date {  get; set; }
        public string reviewer { get; set; }
        public string comment { get; set; }
    }
}



