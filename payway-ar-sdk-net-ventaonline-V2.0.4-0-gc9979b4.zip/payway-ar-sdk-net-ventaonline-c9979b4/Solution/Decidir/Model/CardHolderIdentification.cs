﻿namespace Decidir.Model
{
    public class CardHolderIdentification
    {
        public string type { get; set; }
        public string number { get; set; }
    }
}