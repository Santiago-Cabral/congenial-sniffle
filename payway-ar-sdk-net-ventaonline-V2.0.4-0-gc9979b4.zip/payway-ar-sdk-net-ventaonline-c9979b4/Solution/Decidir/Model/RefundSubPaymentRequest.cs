﻿using System;
using System.Collections.Generic;

namespace Decidir.Model
{
    public class RefundSubPaymentRequest
    {

        public List<RefundSubPayment> sub_payments { get; set; }




    }
}
