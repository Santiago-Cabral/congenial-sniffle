﻿using System;

public class ValidationError
{
    public string code {  get; set; }
    public string param { get; set; }
}
