﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
    public class TargetThreeds
    {
        public String element { get; set; }
        public Boolean visible { get; set; }
        public int width { get; set; }
        public int height { get; set; }

    }
}
