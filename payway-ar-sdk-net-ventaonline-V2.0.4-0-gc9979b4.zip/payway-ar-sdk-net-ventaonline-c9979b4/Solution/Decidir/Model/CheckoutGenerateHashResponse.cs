﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decidir.Model
{
    public class CheckoutGenerateHashResponse
    {
        public string payment_id { get; set; }
        public string status { get; set; }
    }
}
