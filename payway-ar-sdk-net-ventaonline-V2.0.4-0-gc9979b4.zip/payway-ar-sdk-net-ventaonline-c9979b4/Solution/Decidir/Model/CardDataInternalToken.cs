﻿
namespace Decidir.Model
{
    public class CardDataInternalToken
    {
        public string card_number { get; set; }
        public string expiration_date { get; set; }
        public string card_holder { get; set; }
        public string security_code { get; set; }
        public string account_number { get; set; }
        public string email_holder { get; set; }


    }
}
