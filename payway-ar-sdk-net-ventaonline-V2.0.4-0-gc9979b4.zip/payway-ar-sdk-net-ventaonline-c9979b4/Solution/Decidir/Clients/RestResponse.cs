﻿namespace Decidir.Clients
{
    internal class RestResponse
    {
        public int StatusCode { get; set; }
        public string Response { get; set; }
    }
}
